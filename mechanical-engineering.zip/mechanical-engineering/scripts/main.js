require("mechanical-engineering/blocks/production/advanced-presser");
require("mechanical-engineering/blocks/production/basic-circuit-factory");
require("mechanical-engineering/blocks/production/basic-engine-factory");
require("mechanical-engineering/blocks/production/basic-presser");
require("mechanical-engineering/blocks/production/basic-refinery");