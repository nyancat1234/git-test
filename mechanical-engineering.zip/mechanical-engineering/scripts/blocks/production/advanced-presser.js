const multiLib=require("multi-lib/wrapper");
const advancedPresser=multiLib.extend(GenericCrafter,GenericCrafter.GenericCrafterEntity,"advanced-presser",{

},
{
  _output:[
    [[["mechanical-engineering"+"-"+"copper-plate",2]],null,null],
    [[["mechanical-engineering"+"-"+"gold-plate",2]],null,null],
    [[["mechanical-engineering"+"-"+"aluminium-plate",2]],null,null],
    [[["mechanical-engineering"+"-"+"titanium-plate",2]],null,null],
    [[["mechanical-engineering"+"-"+"steel-plate",2]],null,null],
  ],
  _input:[
    [[["copper",3]],[["water",6]],5],
    [[["mechanical-engineering"+"-"+"gold",3]],[["water",6]],5],
    [[["mechanical-engineering"+"-"+"aluminium",3]],[["water",6]],5],
    [[["titanium",3]],[["water",6]],5],
    [[["mechanical-engineering"+"-"+"steel",3]],[["water",6]],5],
  ],
  craftTimes:[60,60,60,60,60],
  output:[],
  input:[],
  itemList:[],
  liquidList:[],
  isSameOutput:[],
});
advancedPresser.enableInv=true;
advancedPresser.dumpToggle=true;