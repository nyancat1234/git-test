const multiLib=require("multi-lib/wrapper");
const basicCricuitFactory=multiLib.extend(GenericCrafter,GenericCrafter.GenericCrafterEntity,"basic-circuit-factory",{

},
{
  _output:[
    [[["mechanical-engineering"+"-"+"basic-circuit",1]],null,null],
    [[["mechanical-engineering"+"-"+"advanced-circuit",1]],null,null],
  ],
  _input:[
    [[["mechanical-engineering"+"-"+"copper-wire",2],["mechanical-engineering"+"-"+"aluminium-plate",1]],null,2.5],
    [[["mechanical-engineering"+"-"+"gold-wire",5],["mechanical-engineering"+"-"+"basic-circuit",2]],null,5],
  ],
  craftTimes:[30,30],
  output:[],
  input:[],
  itemList:[],
  liquidList:[],
  isSameOutput:[],
});
basicCricuitFactory.enableInv=true;
basicCricuitFactory.dumpToggle=true;