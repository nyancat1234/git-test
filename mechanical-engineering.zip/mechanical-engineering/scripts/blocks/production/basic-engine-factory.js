const multiLib=require("multi-lib/wrapper");
const basicEngineFactory=multiLib.extend(GenericCrafter,GenericCrafter.GenericCrafterEntity,"basic-engine-factory",{

},
{
  _output:[
    [[["mechanical-engineering"+"-"+"basic-engine",1]],null,null],
    [[["mechanical-engineering"+"-"+"advanced-engine",1]],null,null],
  ],
  _input:[
    [[["mechanical-engineering"+"-"+"aluminium-plate",2],["mechanical-engineering"+"-"+"titanium-plate",1]],null,2.5],
    [[["mechanical-engineering"+"-"+"basic-engine",2],["mechanical-engineering"+"-"+"steel-plate",2]],null,5],
  ],
  craftTimes:[30,30],
  output:[],
  input:[],
  itemList:[],
  liquidList:[],
  isSameOutput:[],
});
basicEngineFactory.enableInv=true;
basicEngineFactory.dumpToggle=true;