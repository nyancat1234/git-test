const multiLib=require("multi-lib/wrapper");
const basicPresser=multiLib.extend(GenericCrafter,GenericCrafter.GenericCrafterEntity,"basic-presser",{

},
{
  _output:[
    [[["mechanical-engineering"+"-"+"copper-plate",1]],null,null],
    [[["mechanical-engineering"+"-"+"gold-plate",1]],null,null],
    [[["mechanical-engineering"+"-"+"aluminium-plate",1]],null,null],
    [[["mechanical-engineering"+"-"+"titanium-plate",1]],null,null],
    [[["mechanical-engineering"+"-"+"steel-plate",1]],null,null],
  ],
  _input:[
    [[["copper",2]],null,1],
    [[["mechanical-engineering"+"-"+"gold",2]],null,1],
    [[["mechanical-engineering"+"-"+"aluminium",2]],null,1],
    [[["titanium",2]],null,1],
    [[["mechanical-engineering"+"-"+"steel",2]],null,1],
  ],
  craftTimes:[60,60,60,60,60],
  output:[],
  input:[],
  itemList:[],
  liquidList:[],
  isSameOutput:[],
});
basicPresser.enableInv=true;
basicPresser.dumpToggle=true;