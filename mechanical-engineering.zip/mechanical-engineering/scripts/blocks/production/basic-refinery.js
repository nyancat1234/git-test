const multiLib=require("multi-lib/wrapper");
const basicRefinery=multiLib.extend(GenericCrafter,GenericCrafter.GenericCrafterEntity,"basic-refinery",{

},
{
  _output:[
    [[["mechanical-engineering"+"-"+"iron",1]],null,null],
    [[["mechanical-engineering"+"-"+"purified-iron",1]],null,null],
    [[["mechanical-engineering"+"-"+"steel",1]],null,null],
  ],
  _input:[
    [[["scrap",4]],null,1],
    [[["mechanical-engineering"+"-"+"iron",1]],null,2.5],
    [[["mechanical-engineering"+"-"+"purified-iron",10],["graphite",5]],null,5],
  ],
  craftTimes:[15,30,60],
  output:[],
  input:[],
  itemList:[],
  liquidList:[],
  isSameOutput:[],
});
basicRefinery.enableInv=true;
basicRefinery.dumpToggle=true;